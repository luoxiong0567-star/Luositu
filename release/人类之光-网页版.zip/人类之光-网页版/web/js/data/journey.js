/**
 * 「两分钟速览」脚本：八段，十四个落点，合计约 104 秒。
 *
 * 一段 = 一章 = 一句旁白；段内可以串多个镜头（beats）。
 * 这样既能满足"八段"的叙事节奏，又能把十二处现场都走到，
 * 而不必为每一处单独开一段。
 *
 * beat 字段：
 *   scene   场景 id
 *   params  进入后逐条 setParam（场景不认的键会被忽略）
 *   cam     显式机位 [[x,y,z],[tx,ty,tz]]（世界坐标）；不写就用场景自己的 home
 *   zoom    在 home 基础上再乘一个距离系数（<1 推近，>1 拉远）
 *   ms      这一镜停留多久（含飞行时间）
 *   lift    画面整体上移若干像素，避开底部字幕卡
 *   pzoom   仅竖屏（手机）生效的距离系数，缺省 1.3；横屏取景刚好的镜头要单独给大一点
 *   fly     飞行时长（毫秒），缺省 2400
 *   ease    缓动：'in' 越飞越快（冲进太阳标记），'out' 到站减速（连续推进的落点），缺省 easeInOut
 *   from    'hold' = 从上一镜结束时的相机状态直接续飞（连续推进），缺省从落点外侧甩入
 *
 * 时长预算（总时长 ≈ 104 s）：
 *   文字 8 + 宇宙 11.4 + 太阳系 12 + 原子 12 + 分子 18
 *        + 电磁 10 + 引力质能 14 + 思维 19 = 104.4 s
 *
 * 银河 → 太阳系是一口气的连续推进：银河俯瞰 → 加速冲向猎户臂上的太阳标记
 * （easeIn，青色光环充满画面）→ 太阳系从远处减速落位（easeOut）→ 再缓慢推近一层，
 * 三级缩放速度逐级递减，纵深不跳变。
 *
 * 叙事主线：
 *   文字 → 星空 → 银河 → 太阳标记 → 太阳系 → 玻尔原子 → 蛋白 → DNA → 细胞
 *        → 麦克斯韦 → 引力 → 质能 → 神经网络推理 → 智能体
 */
(function (global) {
  'use strict';

  var HL = global.HL = global.HL || {};

  /* 太阳标记俯冲机位。
   *
   * 星系一直在自转（cosmos.js 里 galaxy.rotation.y += dt*0.016），标记的世界坐标
   * 每帧都在动，写死坐标会冲偏，所以这里返回一个函数，由 Journey 在开镜时现取
   * 标记的当前位置，再从"来路方向"（银盘上方偏 +z，正对上一镜的俯瞰视点）
   * 退开 1.5 个单位落位 —— 最后一刻青色光环充满画面，随即切太阳系。 */
  var DIVE_OFF = [0.37, 0.81, 1.22];   // 长度 ≈ 1.51 = 终点半径
  function sunDive() {
    return function () {
      var p = null;
      try {
        var m = HL.manager;
        if (m && m.def && m.def.id === 'cosmos' && m.inst && m.inst.focus) p = m.inst.focus('sun');
      } catch (e) { p = null; }
      if (!p) return null;             // 取不到就退回场景 home，不至于崩
      return [
        [p.x + DIVE_OFF[0], p.y + DIVE_OFF[1], p.z + DIVE_OFF[2]],
        [p.x, p.y, p.z]
      ];
    };
  }

  HL.JOURNEY = [
    /* ── 1 ─────────────────────────────────── 文字 · 8 s */
    {
      kind: 'open', dur: 8000,
      kicker: '序 · 文字',
      title: '人类第一次把世界写下来',
      line: '甲骨上刻下日、月、星、山、水——符号替我们记住了天空，也记住了时间。'
    },

    /* ── 2 ───────────────────── 星空 → 银河 → 太阳标记 · 11.4 s
     * 银河带只给 3.6 s 且飞行占满全程（不再长时间停在原地）；
     * 银河俯瞰后镜头贴着旋臂加速冲向太阳标记（旁白里的"猎户臂上的一个点"），
 * 光环充满画面的一瞬切太阳系。 */
    {
      kicker: 'Ⅰ · 宇宙的法则',
      title: '从仰望到俯瞰',
      line: '抬头，银河横过天顶；退到十二万光年外才看清，那只是猎户臂上的一个点。',
      beats: [
        {
          scene: 'cosmos', params: { view: 'sky', labels: false },
          cam: [[0, 0.4, 0], [-18, 7.5, -34]],
          ms: 3600, fly: 3400
        },
        {
          scene: 'cosmos', params: { view: 'galaxy' }, lift: 26,
          cam: [[0, 15.5, 21], [0, 0, 0]],
          ms: 4800, fly: 2600
        },
        {
          /* 冲进"猎户臂上的一个点"：终点贴着太阳标记（来路方向 1.5 单位处），
           * easeIn 加速，光环充满画面的一瞬切太阳系。坐标现取（星系在自转） */
          scene: 'cosmos',
          params: { spin: false },     // 俯冲这 3 秒定住星系，免得标记从镜头里漂走
          cam: sunDive(),
          from: 'hold', ease: 'in',
          ms: 3000, fly: 3000
        }
      ]
    },

    /* ── 3 ────────────────────────────────── 太阳系 · 12 s
     * 接冲进太阳标记的冲势从远处减速落位（easeOut），再缓缓推近一层——
     * 与上一段的加速衔接成"先快后慢"的连续变焦。 */
    {
      kicker: 'Ⅰ · 宇宙的法则',
      title: '太阳系',
      line: '八颗行星沿椭圆轨道运行：水星八十八天一圈，海王星要一百六十五年，同一套开普勒定律。',
      beats: [
        { scene: 'solar', ms: 7000, fly: 2600, zoom: 0.92, lift: 18, ease: 'out' },
        { scene: 'solar', ms: 5000, fly: 4600, zoom: 0.74, lift: 18, from: 'hold', ease: 'out' }
      ]
    },

    /* ── 4 ─────────────────────────── 玻尔原子（直给）· 12 s */
    {
      kicker: 'Ⅱ · 物质的语言',
      title: '原子：核与壳层',
      line: '原子核在中心，电子按壳层排布：第一层两个位置，第二层八个——化学键的全部脾气，都写在这几层电子的排布里。',
      beats: [
        {
          scene: 'periodic', params: { solo: true, hint: false },
          cam: [[0, 1.2, 10.5], [0, -0.3, 0]],
          lift: 26, ms: 12000, fly: 2600
        }
      ]
    },

    /* ───────────────────────────── 分子 · DNA · 细胞 · 18 s */
    {
      kicker: 'Ⅱ · 物质的语言',
      title: '写在分子上的说明书',
      line: '原子按价键拼成分子，分子编成双螺旋：三十亿个字母写下一个人的全部构造，细胞照着它建起一座城。',
      beats: [
        { scene: 'molecule', params: { mode: 'alpha', spin: true }, lift: 18, ms: 5000, fly: 1500 },
        { scene: 'molecule', params: { mode: 'dna', unwind: 0.35 }, zoom: 1.85, lift: 40, ms: 6000, fly: 1800 },
        { scene: 'animalcell', params: { view: 'overview', cut: 0.35 }, zoom: 1.15, lift: 16, ms: 7000, fly: 2000 }
      ]
    },

    /* ───────────────────────────────── 麦克斯韦方程组 · 10 s
     * 机位抬高拉远、几乎不给 lift：方程卡片挂在 y≈10，压低镜头会把
     * 卡片顶出画面——取景要让波动展台与公式卡片同时完整居中。 */
    {
      kicker: 'Ⅲ · 规律的抽象',
      title: '四行方程写尽电磁',
      line: '变化的磁场生电场，变化的电场生磁场——两条定律互相喂养，扰动便自己跑成了光。',
      beats: [
        {
          scene: 'maxwell', params: { view: 'C', cards: true },
          cam: [[13.24, 4.66, 31.96], [13.0, 3.0, 0]],
          lift: 0, pzoom: 1.35, ms: 10000, fly: 2400
        }
      ]
    },

    /* ─────────────────────────────────── 引力 · 质能 · 14 s */
    {
      kicker: 'Ⅲ · 规律的抽象',
      title: '从引力到质能',
      line: '一条平方反比算出潮汐与行星，一个 E = mc² 就能知道：太阳每秒轻了四百万吨。',
      beats: [
        { scene: 'gravity', params: { sub: 'well' }, lift: 24, ms: 6500, fly: 1900 },
        { scene: 'massenergy', params: { act: 'balance' }, zoom: 1.1, ms: 7500, fly: 1900 }
      ]
    },

    /* ───────────────────────── 神经网络推理 · 智能体 · 19 s */
    {
      kicker: 'Ⅳ · 思维的光芒',
      title: '思维也可以被观察',
      line: '二十八项训练参数喂进多层网络，权重逐层点亮，答案从概率里浮出来；再往前一步，它会规划、会调用工具。',
      beats: [
        { scene: 'neuralnet', ms: 10000, fly: 2200 },
        { scene: 'aiagent', ms: 9000, fly: 2400 }
      ]
    }
  ];

})(window);
